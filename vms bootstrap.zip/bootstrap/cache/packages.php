<?php return array (
  'beyondcode/laravel-dump-server' => 
  array (
    'providers' => 
    array (
      0 => 'BeyondCode\\DumpServer\\DumpServerServiceProvider',
    ),
  ),
  'brian2694/laravel-toastr' => 
  array (
    'providers' => 
    array (
      0 => 'Brian2694\\Toastr\\ToastrServiceProvider',
    ),
    'aliases' => 
    array (
      'Toastr' => 'Brian2694\\Toastr\\Facades\\Toastr',
    ),
  ),
  'darryldecode/cart' => 
  array (
    'providers' => 
    array (
      0 => 'Darryldecode\\Cart\\CartServiceProvider',
    ),
    'aliases' => 
    array (
      'Cart' => 'Darryldecode\\Cart\\Facades\\CartFacade',
    ),
  ),
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'jivesh/laravel-slack' => 
  array (
    'providers' => 
    array (
      0 => 'Gahlawat\\Slack\\SlackServiceProvider',
    ),
    'aliases' => 
    array (
      'Slack' => 'Gahlawat\\Slack\\Facade\\Slack',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'maatwebsite/excel' => 
  array (
    'providers' => 
    array (
      0 => 'Maatwebsite\\Excel\\ExcelServiceProvider',
    ),
    'aliases' => 
    array (
      'Excel' => 'Maatwebsite\\Excel\\Facades\\Excel',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'samerior/mobile-money' => 
  array (
    'providers' => 
    array (
      0 => 'Samerior\\MobileMoney\\MobileMoneyServiceProvider',
    ),
    'aliases' => 
    array (
      'B2C' => 'Samerior\\MobileMoney\\Mpesa\\Facades\\B2C',
      'Identity' => 'Samerior\\MobileMoney\\Mpesa\\Facades\\Identity',
      'Registrar' => 'Samerior\\MobileMoney\\Mpesa\\Facades\\Registrar',
      'STK' => 'Samerior\\MobileMoney\\Mpesa\\Facades\\STK',
    ),
  ),
);