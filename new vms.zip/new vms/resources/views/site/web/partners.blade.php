@extends('site.app')
@section('title', 'Homepage')
@section('content')
    <!-- ========================= SECTION MAIN ========================= -->
    <section class="section-main bg padding-top-sm">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="bg-green">
                        <div class="row">                        
                            <div style="width: 90%; margin-left: 5%; margin-right: 5%;">
                                
                            </div>
                        </div>      
                        <div class="ftco-cover-1 overlay" style="background-color: rgba(68, 114, 196, 0.8);">
                        
                        </div>
                    </div>

  
    <div id="join" class="site-section" style="background-color: #fff; margin-bottom: 20px;">
        <div class="container">
            

    </div>
    </div>
    </div>

    </div></div></section>
@stop
