@extends('site.app')
@section('title', 'Homepage')
@section('content')
    <!-- ========================= SECTION MAIN ========================= -->
    <section class="section-main bg padding-top-sm">
    <div class="container">
        <figure class="card card-product">
            <div class="row">
                
                <div class="col-md-2">
                </div>
                <div class="col-md-8">
                    <hr>
                      
                </div>
                <div class="col-md-2">
                </div>
            </div>
        </figure>
    </div>
    </section>
@stop
