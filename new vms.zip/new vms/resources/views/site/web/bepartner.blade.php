@extends('site.app')
@section('title', 'Homepage')
@section('content')
    <!-- ========================= SECTION MAIN ========================= -->
    <section class="section-main bg padding-top-sm">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="bg-green">
                        <div class="row">                        
                            <div style="width: 90%; margin-left: 10%; margin-right: 5%;">
                                
                            </div>
                        </div>      
                        <div class="ftco-cover-1 overlay" style="background-color: rgba(68, 114, 196, 0.8);">
                        
                        </div>
                    </div>

  
                    <div id="join" class="site-section" style="background-color: #fff; margin-bottom: 20px;">
                        <div class="container">
                            <div style="text-align: center; margin-bottom: 20px;">
                            

            <form action="#">
                <div class="row">
                    <div class="col-md-5">
                        <div class="form-group">
                          <label>Name</label>
                          <input type="text" class="form-control" placeholder="Name">
                        </div>
                    </div>

                    <div class="col-md-5">
                        <div class="form-group">
                          <label>Email Address</label>
                          <input type="email" class="form-control" placeholder="Email">
                        </div>
                    </div>

                    <div class="col-md-5">
                        <div class="form-group">
                          <label>Phone Number</label>
                          <input type="text" class="form-control" placeholder="Phone Number">
                        </div>
                    </div>

                    <div class="col-md-5">
                        <div class="form-group">
                          <label>Country</label>
                          <input type="text" class="form-control" placeholder="Contry">
                        </div>
                    </div>

                    <div class="col-md-5">
                        <div class="form-group">
                          <label>Organization</label>
                          <input type="text" class="form-control" placeholder="Organization">
                        </div>
                    </div>

                    <div class="col-md-5">
                        <div class="form-group">
                          <label>Job Title</label>
                          <input type="email" class="form-control" placeholder="Job">
                        </div>
                    </div>

                    <div class="col-md-5">
                        <div class="form-group">
                          <label>Type of Partnership</label>
                          <input type="text" class="form-control" placeholder="Type">
                        </div>
                    </div>

                    <div class="col-md-5">
                        <div class="form-group">
                          <label>Message</label>
                          <input type="text" class="form-control" placeholder="Message">
                        </div>
                    </div>

                    <div class="col-md-5">
                        <div class="form-group">
                          <input type="submit" value="Send Message" class="btn btn-primary">
                        </div>
                    </div>
                    <div class="col-md-5">
                    </div>
                </div>
              </form>

                        </div>
                    </div>

               
</div>

</div></div></section>

                    <!-- ============== main slidesow .end // ============= -->
                
@stop
