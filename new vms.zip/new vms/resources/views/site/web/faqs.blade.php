@extends('site.app')
@section('title', 'Homepage')
@section('content')
    <!-- ========================= SECTION MAIN ========================= -->
    <section class="section-main bg padding-top-sm">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="bg-green">
                        <div class="row">                        
                            <div style="width: 90%; margin-left: 10%; margin-right: 5%;">
                                <h1 class="text-white mb-3"> </h1>
                                <p class="lead text-white"> </p>
                            </div>
                        </div>      
                        <div class="ftco-cover-1 overlay" style="background-color: rgba(68, 114, 196, 0.8);">
                        
                        </div>
                    </div>

  
    <div id="join" class="site-section" style="background-color: #fff; margin-bottom: 20px;">
        <div class="container">
                <div style="text-align: center; margin-bottom: 20px;"><h4 style="color: #000;">
                    <strong>FAQs</strong></h4>
                </div> 


                    

                </div>
            </div>
       
</div>

 </div></div></section>
@stop
