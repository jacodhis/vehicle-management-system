                <!-- col 2// -->
    <div class="col-md-3">
        <h4>Featured Product</h4>         


            <!-- <div class="row">
                
                    <div class="card mt-1 mb-2">
                        <figure class="itemside">
                            <div class="aside">
                                
                                    <div class="img-wrap padding-x">
                                        <img src="{{ asset('frontend/images/icons/cover/pp1.png') }}" alt="">
                                    </div>
                                
                            </div>

                            <figcaption class="p-3">
                                    <h6 class="title">
                                        <a href="#"> PP1 Package(4 Learning areas per year</a>
                                    </h6>
                                <div class="price-wrap">
                                  
                                    <div class="price-wrap h5">
                                        <span class="price"> 
                                            Ksh 3000
                                        </span>
                                        <del class="price-old"> 
                                            Ksh 4000
                                        </del>
                                    </div>
                                
                                    <div class="price-wrap h5">
                                        <span class="price"> 
                                            
                                        </span>
                                    </div>
                                
                                </div>
                                    <a href="#" class="btn btn-sm btn-success float-right">View Details
                                    </a>
                                
                            </figcaption>
                        </figure>
                    </div> -->
                                       
          <!--   </div> -->
            
            
        <p><a href="{{ route('register') }}" class="btn btn-primary py-3 px-4 ">Request a Free Demo</a></p>           
    </div> 
</section> 